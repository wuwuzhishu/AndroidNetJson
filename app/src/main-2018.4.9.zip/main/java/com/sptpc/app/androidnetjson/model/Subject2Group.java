package com.sptpc.app.androidnetjson.model;

/**
 * Created by wwb on 2018/4/9.
 */
public class Subject2Group {
    private String name;


    public Subject2Group(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
